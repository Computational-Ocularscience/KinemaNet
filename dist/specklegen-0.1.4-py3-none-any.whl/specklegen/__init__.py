# -*- coding: utf-8 -*-
"""
Created on Sun Feb 16 01:58:28 2025

@author: Fisseha
"""

# specklegen/__init__.py
from .synthetic_data_generator import *
